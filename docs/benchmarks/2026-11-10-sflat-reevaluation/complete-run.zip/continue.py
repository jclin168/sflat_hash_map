import os,subprocess,pathlib,json
root=pathlib.Path(__file__).parent
for n in [1000000,10000000,100000000]:
 for r in range(3):
  out=root/'controlled'/str(n)/str(r);out.mkdir(parents=True,exist_ok=True)
  (out/'builds.json').write_text(json.dumps({'sflat_flat_hash_map':{'returncode':0}}))
  with (root/'controlled-progress.log').open('a') as log:
   print(n,r,flush=True)
   subprocess.run(['python3',str(root/'run_controlled.py'),'--build',str(root/'build'),'--out',str(out)],env=dict(os.environ,MAP_BENCH_N=str(n)),stdout=log,stderr=subprocess.STDOUT,check=True)
