#!/bin/sh
set -eu
g++ -DSFLAT_PROCESS_SEED=1 -I/workspace/sflat-rerun/source/include -I/workspace/deps/map_benchmark_full/src/app -I/workspace/deps/map_benchmark_full/external -I/workspace/deps/map_benchmark_full/src/maps/sflat_flat_hash_map -I/workspace/deps/map_benchmark_full/src/hashes/std_hash -DNDEBUG -O3 -march=native -std=gnu++17 /workspace/deps/map_benchmark_full/build-comprehensive/CMakeFiles/bench_sflat_flat_hash_map__std_hash.dir/Unity/unity_0_cxx.cxx -o /workspace/sflat-rerun/build/bench_sflat_flat_hash_map__std_hash
