import json,pathlib,subprocess,os
root=pathlib.Path(__file__).parent
old=pathlib.Path('/workspace/deps/map_benchmark_full/results-comprehensive/runs')
flags=[]
for p in (root/'results/runs').glob('*.json'):
 a=json.loads(p.read_text());b=json.loads((old/p.name).read_text());before=b.get('benchmark_s',0)
 if a['status']=='ok' and b['status']=='ok' and before>=.1 and a['benchmark_s']/before>1.15:flags.append((a['benchmark_s']/before,a['case']))
flags=sorted(flags,reverse=True)[:3]
(root/'followup-selection.json').write_text(json.dumps({'rule':'At most three largest case time increases above 15%, compared with historical data; cases with historical time below 0.1 s are excluded. Run one fresh baseline and one fresh latest process for each selected case. Keep all initial results.','cases':flags},indent=2))
base_script=(root/'run_comprehensive.py').read_text()
for label,build in [('before',pathlib.Path('/workspace/deps/map_benchmark_full/build-comprehensive')),('after',root/'build')]:
 script=base_script;start=script.index('CASES=');end=script.index('\nFIELDS=',start);script=script[:start]+'CASES='+repr([x[1] for x in flags])+script[end:]
 if label=='before':
  script=script.replace("Path('/workspace/sflat-rerun/source/include')","Path('/workspace/deps/map_benchmark_full/external/jclin168__sflat_hash_map/include')").replace("gitsha(Path('/workspace/sflat-rerun/source'))","gitsha(Path('/workspace/deps/map_benchmark_full/external/jclin168__sflat_hash_map'))")
 path=root/('followup-'+label+'.py');path.write_text(script)
 out=root/'followup'/label;out.mkdir(parents=True,exist_ok=True);(out/'builds.json').write_text(json.dumps({'sflat_flat_hash_map':{'returncode':0}}))
 with (root/'followup-progress.log').open('a') as log:subprocess.run(['python3',str(path),'--build',str(build),'--out',str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
