import pathlib,json,csv,hashlib,statistics as st,math,collections,subprocess,shutil,zipfile,time
root=pathlib.Path(__file__).parent
oldroot=pathlib.Path('/workspace/deps/map_benchmark_full/results-comprehensive')
runs=json.loads((root/'results/results.json').read_text());assert len(runs)==20
old={p.stem.split('__',1)[1]:json.loads(p.read_text()) for p in (oldroot/'runs').glob('sflat_flat_hash_map__*.json')}
assert all(r['status']=='ok' for r in runs),[(r['case'],r['status']) for r in runs]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(folder):
 env=json.loads((folder/'environment.json').read_text())
 for p,h in env['source_sha256'].items():assert sha(pathlib.Path(p))==h,p
 for a,h in env['binary_sha256'].items():
  binary=pathlib.Path('/workspace/deps/map_benchmark_full/build-comprehensive')/('bench_'+a+'__std_hash') if 'followup/before' in str(folder) else root/'build'/('bench_'+a+'__std_hash')
  assert sha(binary)==h,str(binary)
 return env
meta=validate(root/'results')
assert subprocess.check_output(['git','-C',str(root/'source'),'status','--porcelain'],text=True)==''
control=[]
for n in [1000000,10000000,100000000]:
 for rep in range(3):
  folder=root/'controlled'/str(n)/str(rep);validate(folder)
  rr=json.loads((folder/'results.json').read_text());assert len(rr)==2 and all(x['status']=='ok' for x in rr)
  for run in rr:control.append(dict(n=n,repeat=rep,**run))
follow={}
for label in ['before','after']:
 folder=root/'followup'/label;validate(folder);rr=json.loads((folder/'results.json').read_text());assert all(x['status']=='ok' for x in rr);follow[label]={x['case']:x for x in rr}
assert set(follow['before'])==set(follow['after'])
for case in ['ShowHash','ShowHashString']:
 assert (root/'results/stdout'/('sflat_flat_hash_map__'+case+'.txt')).read_bytes()==(oldroot/'stdout'/('sflat_flat_hash_map__'+case+'.txt')).read_bytes()
def csvwrite(name,rows,fields=None):
 with (root/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
case_rows=[];phase_rows=[]
for r in runs:
 b=old[r['case']];assert r['status']=='ok' and len(r['rows'])==len(b['rows'])
 case_rows.append({'case':r['case'],'kind':r['kind'],'status':r['status'],'old_runtime_s':b['benchmark_s'],'new_runtime_s':r['benchmark_s'],'time_change_pct':(r['benchmark_s']/b['benchmark_s']-1)*100 if b['benchmark_s'] else '', 'rss_peak_mib':r['rss_peak_bytes']/2**20,'old_rss_peak_mib':b['rss_peak_bytes']/2**20,'observed_vmsize_mib':r['observed_vmsize_bytes']/2**20,'observed_vmpeak_mib':r['observed_vmpeak_bytes']/2**20,'wall_s':r['wall_s']})
 for new,prev in zip(r['rows'],b['rows']):
  assert new['measurement']==prev['measurement'] and new['measurement_id']==prev['measurement_id']
  assert new['actual_result']==prev['actual_result']
  a,c=float(prev['runtime_s']),float(new['runtime_s'])
  phase_rows.append({'case':r['case'],'measurement_id':new['measurement_id'],'measurement':new['measurement'],'actual_result':new['actual_result'],'old_runtime_s':a,'new_runtime_s':c,'time_change_pct':(c/a-1)*100 if a else ''})
csvwrite('case-comparison.csv',case_rows);csvwrite('phase-comparison.csv',phase_rows)
summary=[]
for n in [1000000,10000000,100000000]:
 for case in ['FlatMap64Reserved','FlatMap64Grow']:
  selected=[r for r in control if r['n']==n and r['case']==case]
  for i in range(len(selected[0]['rows'])):
   seconds=[float(r['rows'][i]['runtime_s']) for r in selected]
   summary.append({'n':n,'case':case,'measurement':selected[0]['rows'][i]['measurement'],'repeats':3,'median_runtime_s':st.median(seconds),'min_runtime_s':min(seconds),'max_runtime_s':max(seconds),'median_rss_current_mib':st.median(float(r['rows'][i]['rss_current_mib']) for r in selected),'median_process_peak_rss_mib':st.median(r['rss_peak_bytes']/2**20 for r in selected),'median_process_vmpeak_mib':st.median(r['observed_vmpeak_bytes']/2**20 for r in selected)})
csvwrite('controlled-summary.csv',summary)
followrows=[{'case':case,'before_runtime_s':follow['before'][case]['benchmark_s'],'after_runtime_s':follow['after'][case]['benchmark_s'],'time_change_pct':(follow['after'][case]['benchmark_s']/follow['before'][case]['benchmark_s']-1)*100} for case in follow['before']]
csvwrite('followup-comparison.csv',followrows,['case','before_runtime_s','after_runtime_s','time_change_pct'])
core=[r for r in runs if r['kind']=='timed' and not r['case'].startswith('CtorDtor')]
gm=math.exp(st.mean(math.log(r['benchmark_s']/old[r['case']]['benchmark_s']) for r in core))
no_copy=[r for r in core if r['case']!='Copy'];gm_without=math.exp(st.mean(math.log(r['benchmark_s']/old[r['case']]['benchmark_s']) for r in no_copy))
copy=next(r for r in runs if r['case']=='Copy');huge=next(r for r in runs if r['case']=='InsertHugeInt')
text=f'''# Comprehensive sflat reevaluation

## Scope and outcome

Test sflat only. Use main commit `{meta['dependencies']['sflat_actual_include_override']}` with std::hash. Rebuild the full map_benchmark executable from source. Keep the original input sizes and loop counts.

All 20 original cases passed: 17 timed cases and three diagnostics. All 18 controlled processes also passed. They cover 1M, 10M, and 100M entries, with three repeats per size and two cases per repeat. Result checks passed in each measured phase. No process reached the timeout or memory watchdog. No library source change, push, pull request, or merge was done for this task.

Copy took {copy['benchmark_s']:.6f} s, compared with {old['Copy']['benchmark_s']:.6f} s in the historical run. The original InsertHugeInt case took {huge['benchmark_s']:.6f} s and used {huge['rss_peak_bytes']/2**30:.3f} GiB process peak RSS. InsertHugeInt makes 100M insertion attempts and then clears the table. It is distinct from the controlled case with 100M unique live entries.

The equal-weight geometric mean time ratio across the 15 core cases is {gm:.4f} times the historical sflat time. Excluding Copy, the ratio is {gm_without:.4f}. These compare two runs of sflat. They are not a new ranking against other containers. The historical run and this run used the same machine configuration, but they ran at different times.

## Original cases

Each timed case has one fresh process. Time is the sum of its measured phases. It excludes work outside the benchmark timers. Negative change means less time. RSS and virtual peak values cover the whole process.

| Case | Before, s | Latest, s | Time change | Peak RSS, MiB | Observed virtual peak, MiB |
|---|---:|---:|---:|---:|---:|
'''
for r in case_rows:
 if r['kind']=='diagnostic':text+=f"| {r['case']} | diagnostic | PASS | — | {r['rss_peak_mib']:.1f} | {r['observed_vmpeak_mib']:.1f} |\n"
 else:text+=f"| {r['case']} | {r['old_runtime_s']:.6f} | {r['new_runtime_s']:.6f} | {r['time_change_pct']:+.1f}% | {r['rss_peak_mib']:.1f} | {r['observed_vmpeak_mib']:.1f} |\n"
text+='''
The baseline is the retained sflat result from the original comprehensive run. It uses header commit `f163c3d`. Hash diagnostic output is byte-for-byte equal in the old and new runs. Stable-reference output is a diagnostic observation, not an API guarantee. Empty-constructor timing can be removed by compiler optimization.

## Controlled insert and find

Use unique 64-bit keys, 64-bit values, std::hash, and input seed 42. The reserved case times reserve plus insert, random hit lookup, then miss lookup. The growth case times insert without reserve. There is no clear operation in these cases. Times below are medians of three fresh processes. The CSV also includes each range and the memory metrics.

| Live entries | Reserve + insert, s | Insert without reserve, s | Random find hit, s | Find miss, s |
|---|---:|---:|---:|---:|
'''
for n in [1000000,10000000,100000000]:
 ss=[r for r in summary if r['n']==n];v={r['measurement'].split(' n=')[0]:r['median_runtime_s'] for r in ss}
 text+=f"| {n:,} | {v['reserve+insert']:.6f} | {v['insert_grow']:.6f} | {v['find_hit_random']:.6f} | {v['find_miss']:.6f} |\n"
text+='''
| Live entries | Reserved process peak RSS, MiB | Reserved virtual peak, MiB | Growth process peak RSS, MiB | Growth virtual peak, MiB |
|---|---:|---:|---:|---:|
'''
for n in [1000000,10000000,100000000]:
 a=next(r for r in summary if r['n']==n and r['case']=='FlatMap64Reserved');b=next(r for r in summary if r['n']==n and r['case']=='FlatMap64Grow')
 text+=f"| {n:,} | {a['median_process_peak_rss_mib']:.1f} | {a['median_process_vmpeak_mib']:.1f} | {b['median_process_peak_rss_mib']:.1f} | {b['median_process_vmpeak_mib']:.1f} |\n"
text+='''
Memory is not table-only storage. It includes the input key vector, executable, allocator, and temporary storage. The key vector alone uses about 7.6, 76.3, and 762.9 MiB at the three sizes. RSS measures resident pages. Virtual peak measures address space. The two quantities have different meanings. Virtual peaks are sampled at 5 ms intervals; short peaks can be missed. Small-process RSS can be dominated by startup memory.

## Checks for large time increases

Select at most the three largest time increases above 15% against historical data. Exclude cases whose historical time is below 0.1 s. Run one fresh baseline process and one fresh latest process for each selected case. Keep the first full-run results in the table above. This check does not replace them.

| Case | Fresh baseline, s | Fresh latest, s | Time change |
|---|---:|---:|---:|
'''
for r in followrows:text+=f"| {r['case']} | {r['before_runtime_s']:.6f} | {r['after_runtime_s']:.6f} | {r['time_change_pct']:+.1f}% |\n"
if not followrows:text+='| No case exceeded the selection threshold | — | — | — |\n'
for r in followrows:
 if abs(r['time_change_pct'])<=5:
  text+=f"\nThe fresh check for {r['case']} does not repeat the initial large time increase. Its time change is {r['time_change_pct']:+.1f}%.\n"
 elif r['time_change_pct']>15:
  text+=f"\nThe fresh check for {r['case']} again shows more than 15% extra time. This needs profiling before any causal claim. No code change was made in this reevaluation.\n"
 else:
  text+=f"\nThe fresh check for {r['case']} changes time by {r['time_change_pct']:+.1f}%. Compare both samples, rather than only the first result.\n"
text+='''
A single pair can check the direction of a large difference. It cannot establish a stable small speed difference. Do not infer a code defect from a comparison with an old run alone. The full-run phase CSV shows where each time difference occurs.

## Configuration and limits

Intel Xeon Platinum 8573C; Linux x86-64; GCC 14.2; C++17. Flags: `-O3 -DNDEBUG -march=native -DSFLAT_PROCESS_SEED=1`. Use default sflat growth, copy slack, load factor, and huge-page macros. Processes run sequentially on CPU 0. No compile or correctness workload runs at the same time as timed measurements.

The cgroup permits two CPU cores and 8 GiB memory. Each process has a 180 s timeout and a 7 GiB RSS watchdog. A second watchdog stops at 7.5 GiB cgroup memory. There is no virtual-address limit. The runner records memory events before and after each process. No OOM event occurred.

The original suite covers integer, string, copy, iteration, insert/erase, and application workloads. It does not test every key/value type, custom allocator, custom hasher, platform, thread pattern, or macro combination. StringHashBench and disabled Strings.cpp are not registered cases. FlatMap64 is an additional profile, outside the 20 original cases. The exact latest headers already passed the copy change's correctness and sanitizer checks; this task measures the benchmark result checks.

## Files and reproduction

- `case-comparison.csv`: all original case times and process memory.
- `phase-comparison.csv`: old/new measured phases and expected result checks.
- `controlled-summary.csv`: three-repeat insert/find medians and ranges.
- `followup-comparison.csv`: fresh baseline checks for large time increases.
- `results/`: full-run environment, stdout, stderr, JSON checkpoints, and raw phase CSV.
- `controlled/`: raw results for each size and repeat.
- `followup/`: raw fresh-baseline and latest checks.
- `historical/`: the 20 retained historical sflat checkpoints used in the comparison.
- `build-command.sh`: the exact compile command.
- `validation.json`: source, binary, result, and memory-event checks.

The build uses the same frozen benchmark source as the [comprehensive comparison](https://github.com/jclin168/map_benchmark/blob/master/docs/results/2026-11-10-stdhash/REPORT.md). The first include directory selects latest sflat. The old embedded sflat dependency is not the measured header; `sflat_actual_include_override` identifies the actual header revision. Environment files include full source and executable SHA-256 values.

In the original workspace, run `build-command.sh`, then `run_comprehensive.py --build /workspace/sflat-rerun/build --out /path/to/new-results`. Run controlled cases with `MAP_BENCH_N` set to the size and `MAP_BENCH_SEED=42`. The runners use absolute paths from the measured workspace. On another machine, update those paths and use the recorded dependency revisions. Results can change with CPU, compiler, operating system, page policy, and machine load.
'''
(root/'REPORT.md').write_text(text)
history=root/'historical';history.mkdir(exist_ok=True)
for p in (oldroot/'runs').glob('sflat_flat_hash_map__*.json'):shutil.copy(p,history/p.name)
events=[]
for r in runs+control+[x for v in follow.values() for x in v.values()]:
 def ev(s):return {k:int(v) for k,v in (line.split() for line in s.splitlines())}
 a,b=ev(r['memory_events_before']),ev(r['memory_events_after']);assert b.get('oom_kill',0)==a.get('oom_kill',0) and b.get('oom',0)==a.get('oom',0)
 events.append({k:b[k]-a.get(k,0) for k in b})
validation={'native_cases':20,'native_all_ok':True,'controlled_processes':18,'controlled_all_ok':True,'followup_processes':sum(map(len,follow.values())),'followup_all_ok':True,'native_phase_count':sum(len(r['rows']) for r in runs),'controlled_phase_count':sum(len(r['rows']) for r in control),'baseline_phase_result_checks_match':True,'sources_and_binaries_unchanged':True,'source_worktree_clean':True,'memory_event_deltas':events,'sflat_commit':meta['dependencies']['sflat_actual_include_override'],'completed_utc':time.strftime('%FT%TZ',time.gmtime())}
(root/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
include=['REPORT.md','case-comparison.csv','phase-comparison.csv','controlled-summary.csv','followup-comparison.csv','validation.json','build-command.sh','build.log','run_comprehensive.py','run_controlled.py','continue.py','followup.py','followup-before.py','followup-after.py','followup-selection.json','report.py','progress.log','controlled-progress.log','followup-progress.log']
paths=[root/n for n in include if (root/n).is_file()]
for name in ['results','controlled','followup','historical']:
 paths.extend(p for p in (root/name).rglob('*') if p.is_file() and p.suffix!='.tmp')
(root/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(root))+'\n' for p in sorted(paths)))
paths.append(root/'SHA256SUMS')
archive=root.parent/'sflat-rerun-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,str(p.relative_to(root)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps(validation));print('archive',archive,'sha256',sha(archive))
